# AngryBirds
-------------------------------------------------
Angry Birds :anger: :bird: Game using JavaScript. 

# Contributors

#### Authors:

*  ![Mahdi7s](https://github.com/Mahdi7s)

*  ![tonikolaba](https://github.com/tonikolaba)

![Alt text](https://github.com/tonikolaba/download/blob/master/info/artofsoullogoVOG.png?raw=true"ArtofSoul")
